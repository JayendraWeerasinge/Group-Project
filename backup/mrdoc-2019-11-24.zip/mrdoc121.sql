#
# TABLE STRUCTURE FOR: autobackup
#

DROP TABLE IF EXISTS `autobackup`;

CREATE TABLE `autobackup` (
  `id` varchar(1) NOT NULL,
  `action` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `autobackup` (`id`, `action`) VALUES ('1', 'false');


#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS `backup`;

CREATE TABLE `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(50) DEFAULT NULL,
  `backup_name_file` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: category_data
#

DROP TABLE IF EXISTS `category_data`;

CREATE TABLE `category_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: external
#

DROP TABLE IF EXISTS `external`;

CREATE TABLE `external` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: fileupload
#

DROP TABLE IF EXISTS `fileupload`;

CREATE TABLE `fileupload` (
  `file_name` varchar(250) NOT NULL,
  `date_created` varchar(30) NOT NULL,
  `category` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `academic_year` varchar(70) NOT NULL,
  `subject_code` varchar(70) NOT NULL,
  `author` varchar(10) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `lecturer` varchar(250) NOT NULL,
  `doc_type` varchar(250) NOT NULL,
  PRIMARY KEY (`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `msg` varchar(1000) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: postgraduate
#

DROP TABLE IF EXISTS `postgraduate`;

CREATE TABLE `postgraduate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('admin', '123', 'qac', '1232@AFS', 'qac_head', '');


