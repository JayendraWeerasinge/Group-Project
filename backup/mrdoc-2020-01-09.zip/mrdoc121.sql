#
# TABLE STRUCTURE FOR: autobackup
#

DROP TABLE IF EXISTS `autobackup`;

CREATE TABLE `autobackup` (
  `id` varchar(1) NOT NULL,
  `action` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `autobackup` (`id`, `action`) VALUES ('1', 'true');


#
# TABLE STRUCTURE FOR: backup
#

DROP TABLE IF EXISTS `backup`;

CREATE TABLE `backup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(50) DEFAULT NULL,
  `backup_name_file` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (1, '2019-11-23', 'mrdoc-2019-11-23.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (2, '2019-11-28', 'mrdoc-2019-11-28.zip');
INSERT INTO `backup` (`id`, `date`, `backup_name_file`) VALUES (3, '2020-01-09', 'mrdoc-2020-01-09.zip');


#
# TABLE STRUCTURE FOR: category_data
#

DROP TABLE IF EXISTS `category_data`;

CREATE TABLE `category_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `category_data` (`id`, `category`) VALUES (2, 'is');


#
# TABLE STRUCTURE FOR: external
#

DROP TABLE IF EXISTS `external`;

CREATE TABLE `external` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: fileupload
#

DROP TABLE IF EXISTS `fileupload`;

CREATE TABLE `fileupload` (
  `file_name` varchar(250) NOT NULL,
  `date_created` varchar(30) NOT NULL,
  `category` varchar(100) NOT NULL,
  `year` int(11) NOT NULL,
  `semester` varchar(30) NOT NULL,
  `academic_year` varchar(70) NOT NULL,
  `subject_code` varchar(70) NOT NULL,
  `author` varchar(10) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `lecturer` varchar(250) NOT NULL,
  `doc_type` varchar(250) NOT NULL,
  PRIMARY KEY (`file_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('is1y1semIS1102dilanka2018.pdf', '2019-11-28 (11:36:56am)', 'is', 1, '1sem', '2018', 'IS1102', 'dilanka', ' mm', 'dilanka', 'under_graduate');
INSERT INTO `fileupload` (`file_name`, `date_created`, `category`, `year`, `semester`, `academic_year`, `subject_code`, `author`, `comment`, `lecturer`, `doc_type`) VALUES ('is1y1semIS1102h2016.pdf', '2019-12-01 (01:17:49pm)', 'is', 1, '1sem', '2016', 'IS1102', 'dilanka', ' ', 'h', 'under_graduate');


#
# TABLE STRUCTURE FOR: is
#

DROP TABLE IF EXISTS `is`;

CREATE TABLE `is` (
  `subject_code` varchar(10) NOT NULL,
  `subject_name` varchar(100) NOT NULL,
  `year` varchar(10) NOT NULL,
  `semester` varchar(10) NOT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: messages
#

DROP TABLE IF EXISTS `messages`;

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) NOT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `msg` varchar(1000) DEFAULT NULL,
  `date` varchar(50) DEFAULT NULL,
  `time` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (16, 'dilanka', 'to_head_of_institute', 'want to delete is1y1semIS1102h2016.pdffile. Give permission to delete this file by sending PIN', '2019-12-01', '02:21:26pm');
INSERT INTO `messages` (`id`, `sender`, `receiver`, `msg`, `date`, `time`) VALUES (17, 'h', 'to_qac', 'want to delete is1y1semIS1102h2016.pdf file. Give permission to delete this file by sending PIN', '2019-12-01', '02:22:15pm');


#
# TABLE STRUCTURE FOR: pin
#

DROP TABLE IF EXISTS `pin`;

CREATE TABLE `pin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `filename` varchar(250) NOT NULL,
  `actiontype` varchar(250) NOT NULL,
  `code` varchar(5) NOT NULL,
  `msg` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `pin` (`id`, `filename`, `actiontype`, `code`, `msg`) VALUES (31, 'is1y1semIS1102dilanka2018.pdf', 'request_pin', '#####', 'message');
INSERT INTO `pin` (`id`, `filename`, `actiontype`, `code`, `msg`) VALUES (32, 'is1y1semIS1102dilanka2018.pdf', 'request_pin', '#####', 'message');
INSERT INTO `pin` (`id`, `filename`, `actiontype`, `code`, `msg`) VALUES (33, 'is1y1semIS1102dilanka2018.pdf', 'request_to_delete', '77231', 'asdasd');
INSERT INTO `pin` (`id`, `filename`, `actiontype`, `code`, `msg`) VALUES (34, 'is1y1semIS1102dilanka2018.pdf', 'request_to_delete', '79061', 'asdasd');
INSERT INTO `pin` (`id`, `filename`, `actiontype`, `code`, `msg`) VALUES (35, 'is1y1semIS1102dilanka2018.pdf', 'request_to_delete', '67993', 'asdasd');


#
# TABLE STRUCTURE FOR: postgraduate
#

DROP TABLE IF EXISTS `postgraduate`;

CREATE TABLE `postgraduate` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `username` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `course_name` varchar(100) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('2', '4cf85d51b420a2d6f767a8e74f66ed71', 'qac', 'R8cuOLqI@fss', 'qac', '');
INSERT INTO `user` (`username`, `password`, `type`, `email`, `post`, `course_name`) VALUES ('dilanka', '202cb962ac59075b964b07152d234b70', 'qac', 'dilankanimasra105@gmail.com', 'qac_head', '');


